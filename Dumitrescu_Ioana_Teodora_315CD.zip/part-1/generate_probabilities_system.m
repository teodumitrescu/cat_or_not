function [A, b] = generate_probabilities_system(rows)
  
  %gasim numarul de elemente care va fi si dimensiunea matricii
  %acesta e egal cu suma lui gauss pentru x = rows
  n = rows*(rows+1)/2;
  %vectorul b va avea 1 doar pe ultimele "rows" pozitii pentru ca
  %numarul de valori de pe un rand este egal cu numarul randului si
  %"rows" este ultimul rand
  b = zeros(n,1);
  b([n-rows+1:n]) = 1;
  
  %initializam cu zero matricea A
  A = zeros(n);
  
  %cream legaturile elementului 1 (varful), adica punem in matrice -1
  %atat la elementul de pe linia lui, cat si la elementul de pe coloana
  %la elem Aii vo pune nr de intersectii din punctul i (in colturi va fi 4)
  A(1,1) = 4;
  A(1,2) = A(2,1) = -1;
  A(1,3) = A(3,1) = -1;
  
  %vom tine minte care este valoarea cea mai din stanga de pe rand si cea mai 
  %din dreapta (acestea se comporta diferit fata de valorile din mijloc)
  crt_left = crt_right = 1;
  
  for row =  2:rows
    
    %aceasta este formula gasita pentru identificarea urmatorului inceput/sfarsit
    %de rand
    crt_left = crt_left+row - 1;
    crt_right = crt_left + row - 1;
    
    %toate legaturile dintre elementul curent si elementele din: stanga si dreapta
    %(acolo unde exista) si stanga jos si dreapta jos sunt marcate cu -1
    A(crt_left,crt_left+1) = A(crt_left+1, crt_left) = -1;
    A(crt_right,crt_right-1) = A(crt_right-1, crt_right) = -1;
    
    %creez legaturile pt marignile de la randul curent
    if row != rows
      %elementele de pe margini vor avea cate 5 intersectii mereu
      A(crt_left,crt_left) = 5;
      A(crt_left,crt_left+row) = A(crt_left+row,crt_left) = -1;
      A(crt_left,crt_left+row+1) = A(crt_left+row+1,crt_left) = -1;
      
      A(crt_right,crt_right) = 5; 
      A(crt_right,crt_right+row) = A(crt_right+row,crt_right) = -1;
      A(crt_right,crt_right+row+1) = A(crt_right+row+1,crt_right) = -1;
    else
      %elementele din colturi au 4 intersectii
      A(crt_left,crt_left) = 4;
      A(crt_right,crt_right) = 4;
    endif
    
    %se creeaza legaturile pentru elementele din mijloc
    for crt = (crt_left+1):(crt_right-1)
      
      A(crt,crt+1) = A(crt+1,crt) = A(crt,crt-1) = A(crt-1,crt) = -1;
      
      if(row != rows)
      %elementele din mijloc vor avea mereu 6 intersectii
        A(crt,crt) = 6;
        A(crt,crt+row) = A(crt+row,crt) = A(crt,crt+row+1) = A(crt+row+1,crt) = -1;
      else
        %pe ultimul rand, elementele din mijloc au doar 5 intersectii
        A(crt,crt) = 5;
      endif
      
    endfor
  
  endfor
  
endfunction