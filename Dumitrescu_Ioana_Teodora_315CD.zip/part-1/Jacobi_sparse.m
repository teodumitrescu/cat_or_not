function [x] = Jacobi_sparse(G_values, G_colind, G_rowptr, c, tol)
  
  %formam vectorul ce are toate elementele 0 (solutia initiala)
  x_prev = diag(zeros(size(G_rowptr, 2)-1));
  %obtinem pasul curent prin multiplicare cu matricea de iteratie si adaugarea
  %vectorului de iteratie c
  x = csr_multiplication(G_values, G_colind, G_rowptr, x_prev) + c;
  %calculam eroarea aferenta acestui pas
  max_error = max(abs(x - x_prev));

  while max_error > tol
    %cat timp eroarea este mai mare, repetam procedeul
    x_prev = x;
    x = csr_multiplication(G_values, G_colind, G_rowptr, x_prev) + c;
    max_error = max(abs(x - x_prev));
  end
endfunction