function [values, colind, rowptr] = matrix_to_csr(A)

    n = size(A,1);
    nz = 0;
    crt_val = crt_colind = crt_rowptr = 1;

    %parcurgem fiecare element 
    for crt_row = 1:size(A,1)
      first_elem_found = 0;
      for crt_col =1:size(A,2)
        %verificam daca elementul e nenul
        if A(crt_row, crt_col) != 0
          %in caz afirmativ, plusam numarul de elemente nenule
          nz++;
          %adaugam elementul in values
          values(1, crt_val) = A(crt_row,crt_col);
          %adaugam coloana pe care se afla in colind
          colind(1, crt_colind) = crt_col;
          %daca e primul element, adaugam pozitia sa din values in rowptr
          if first_elem_found == 0
            first_elem_found = 1;
            rowptr(1, crt_rowptr) = crt_val;
            crt_rowptr++;
          end
          crt_val++;
          crt_colind++;
        end
      end
    end
    %adaugam elementul cu valoarea nz+1 pe ultima pozite
      rowptr(1, crt_rowptr) = nz + 1; 
endfunction