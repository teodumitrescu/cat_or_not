function [G_J, c_J] = Jacobi_factorization(A, b)
  
  %obtinem matricea diagonala extragand vectorul cu elementele de pe diagonala
  %si apeland "diag" iar pentru a aseza elementele in pe diagonala unei matrice
  %cu zero uri
  N = diag(diag(A));
  %il formam pe P prin scaderea matricei initiale din matricea ce contine
  %diagonala sa
  P = N - A;
  
  %construim G si c prin formulele specifice factorizarii Jacobi
  G_J = inv(N)*P;
  c_J = inv(N)*b;
  
endfunction
