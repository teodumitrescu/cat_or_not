function [cost] = compute_cost_pc(points, centroids)
  
  cost = 0;
  pairs_point_centroid = diag(zeros(size(points,1)));
  
  %iau fiecare punct si calculez care e cel mai apropiat centroid prin calcularea
  %distantei euclidiene minime, salvandu-l in vectorul auxiliar
  for crt_point = 1:size(points,1)
    min_distance = realmax;
    best_centroid = 0;
    for crt_centroid = 1:size(centroids,1)
      crt_distance = norm(points(crt_point,:) - centroids(crt_centroid,:));
      if (crt_distance < min_distance)
        min_distance = crt_distance;
        best_centroid = crt_centroid;
      end
    end
    pairs_point_centroid(crt_point, 1) = best_centroid;
  end
  
  centroids_for_points = zeros(size(points));
  
  %creez o matrice de dimensiunea celei de puncte, punand pe randuri centroidul
  %corespunzator punctului de la indicele respectiv
  for crt_pair = 1:size(pairs_point_centroid,1)
    centroids_for_points(crt_pair,:) = centroids(pairs_point_centroid(crt_pair),:);
  endfor
    output_precision(17);
    %calulez tretat suma normelor
  norm = (points - centroids_for_points).^2;
  cost = sum(sqrt(sum(norm,2)));

 
endfunction

