function [centroids] = clustering_pc(points, NC)
  
  %initializez grupele, centroizii si clusterele
  pairs_point_cluster = [1:size(points,1)]';
  centroids = zeros(NC, size(points,2));
  nr_in_cluster = zeros(NC,1);
 
  %formez clusterele prin tinerea unui vector auxiliar ce leaga punctul de
  %indicele clusterului in care ar trebui sa fie
  pairs_point_cluster = mod(pairs_point_cluster,NC);
  
  %formez centroizii initiali ca valoare, adunand valurile punctelor in clusterul
  %aferent lor si numarand cate puncte sunt in fiecare cluster
  for i = 1:size(points,1) 
    y = pairs_point_cluster(i);
    if y == 0
      y = NC;
    endif
    centroids(y, :) += points(i,:);
    nr_in_cluster(y,1)++;
  endfor

  auxmat = zeros(NC,size(points,2));
  %creez o matrice de dimensiunea celei cu centroizi ce contine numarul de
  %elemente (pentru a imparti apoi sumele formate si a calcula media)
  for k = 1:size(points,2)
    auxmat(:,k) = nr_in_cluster;
  endfor

  centroids = centroids ./auxmat;
 
  %salvez valoarea precedenta intr-o alta matrice
  prev_centroids = zeros(NC,size(points,2));

  while max(max(abs(centroids - prev_centroids))) >= 1e-5
    
    prev_centroids = centroids;
    
    %iau fiecare punct si calculez care e cel mai apropiat centroid, salvandu-l
    %in vectorul auxiliar
    for crt_point = 1:size(points,1)
      min_distance = realmax;
      best_centroid = 0;
      for crt_centroid = 1:size(centroids,1)
        crt_distance = norm(points(crt_point,:) - centroids(crt_centroid,:));
        if (crt_distance < min_distance)
          min_distance = crt_distance;
          best_centroid = crt_centroid;
        endif
      endfor
      pairs_point_cluster(crt_point,1) = best_centroid;
    endfor
  
  %recalculez centroizii in functie de noua impartire
    centroids = zeros(NC, size(points,2));
    nr_in_cluster = zeros(NC,1);
   
    for i = 1:size(points,1)
      y = pairs_point_cluster(i);
      if y == 0
        y = NC;
      endif
      centroids(y, :) += points(i,:);
      nr_in_cluster(y,1)++;
    endfor
    auxmat = zeros(NC,size(points,2));
    for k = 1:size(points,2)
      auxmat(:,k) = nr_in_cluster;
    endfor
    
    centroids = centroids ./auxmat;
 
  endwhile
 
endfunction
